#include "gimbal_app.h"
#include "dm4310.h"
#include "fdcan.h"
#include "gimbal_config.h"
#include "main.h"
#include "usb_console.h"
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

#define DEG_TO_RAD 0.01745329251994329577f

volatile GimbalDebug g_gimbal_debug;

typedef enum
{
    CALRUN_IDLE = 0,
    CALRUN_WAIT_READY = 1,
    CALRUN_COUNTDOWN = 2,
    CALRUN_POSITIVE = 3,
    CALRUN_RETURN_FROM_POSITIVE = 4,
    CALRUN_NEGATIVE = 5,
    CALRUN_FINAL_RETURN = 6
} CalRunPhase;

static GimbalState s_state;
static GimbalFault s_fault;
static uint32_t s_state_start_ms;
static uint32_t s_arm_deadline_ms;
static uint32_t s_power_arm_deadline_ms;
static uint32_t s_power_off_deadline_ms;
static uint32_t s_post_jog_disable_deadline_ms;
static uint32_t s_next_motor_tx_ms;
static uint8_t s_disable_burst;
static uint8_t s_power_output_enabled;
static uint8_t s_level_zero_valid;
static uint8_t s_zero_referenced_motion;
static CalRunPhase s_calrun_phase;
static uint32_t s_calrun_deadline_ms;
static int32_t s_calrun_amplitude_tenths_deg;
static float s_level_zero_rad;
static float s_neutral_rad;
static float s_requested_rad;
static float s_command_rad;
static float s_sweep_amplitude_rad;
static int8_t s_sweep_direction;
static VisionSample s_vision;
static uint8_t s_vision_received;

static uint8_t time_reached(uint32_t now_ms, uint32_t deadline_ms)
{
    return ((int32_t)(now_ms - deadline_ms) >= 0) ? 1U : 0U;
}

static void power_output_force_off(void)
{
    HAL_GPIO_WritePin(POWER_24V_1_GPIO_Port,
                      POWER_24V_1_Pin,
                      GPIO_PIN_RESET);
    s_power_output_enabled = 0U;
    s_power_arm_deadline_ms = 0U;
    s_power_off_deadline_ms = 0U;
    s_post_jog_disable_deadline_ms = 0U;
    s_level_zero_valid = 0U;
    s_level_zero_rad = 0.0f;
    s_zero_referenced_motion = 0U;
    s_calrun_phase = CALRUN_IDLE;
    s_calrun_deadline_ms = 0U;
}

static uint8_t power_arm_is_valid(uint32_t now_ms)
{
    if (s_power_arm_deadline_ms == 0U)
    {
        return 0U;
    }
    return (time_reached(now_ms, s_power_arm_deadline_ms) == 0U) ? 1U : 0U;
}

static uint8_t power_output_is_ready(void)
{
    return ((s_power_output_enabled != 0U) &&
            (s_disable_burst == 0U)) ? 1U : 0U;
}

static uint8_t arm_power_output(uint32_t now_ms)
{
#if GIMBAL_ALLOW_BOARD_POWER_OUTPUT
    if ((s_state != GIMBAL_STATE_SAFE_IDLE) ||
        (s_fault != GIMBAL_FAULT_NONE) ||
        (s_power_output_enabled != 0U))
    {
        return 0U;
    }
    s_power_arm_deadline_ms = now_ms + GIMBAL_POWER_ARM_WINDOW_MS;
    return 1U;
#else
    (void)now_ms;
    return 0U;
#endif
}

static uint8_t power_output_enable(uint32_t now_ms)
{
#if GIMBAL_ALLOW_BOARD_POWER_OUTPUT
    if ((power_arm_is_valid(now_ms) == 0U) ||
        (s_state != GIMBAL_STATE_SAFE_IDLE) ||
        (s_fault != GIMBAL_FAULT_NONE) ||
        (s_power_output_enabled != 0U))
    {
        return 0U;
    }

    HAL_GPIO_WritePin(POWER_24V_1_GPIO_Port,
                      POWER_24V_1_Pin,
                      GPIO_PIN_SET);
    s_power_output_enabled = 1U;
    s_power_arm_deadline_ms = 0U;
    s_power_off_deadline_ms = now_ms + GIMBAL_POWER_ON_TIMEOUT_MS;

    /*
     * Allow the DM4310 to boot, then transmit a disable burst before any
     * OBSERVE or motion request can be accepted.
     */
    s_disable_burst = GIMBAL_DISABLE_BURST_COUNT;
    s_next_motor_tx_ms = now_ms + GIMBAL_POWER_STARTUP_SETTLE_MS;
    return 1U;
#else
    (void)now_ms;
    return 0U;
#endif
}

static float absolute_float(float value)
{
    return (value < 0.0f) ? -value : value;
}

static float clamp_float(float value, float minimum, float maximum)
{
    if (value < minimum)
    {
        return minimum;
    }
    if (value > maximum)
    {
        return maximum;
    }
    return value;
}

static const char *state_name(GimbalState state)
{
    switch (state)
    {
        case GIMBAL_STATE_BOOT: return "BOOT";
        case GIMBAL_STATE_SAFE_IDLE: return "SAFE_IDLE";
        case GIMBAL_STATE_OBSERVE: return "OBSERVE";
        case GIMBAL_STATE_HOLD: return "HOLD";
        case GIMBAL_STATE_STEP: return "STEP";
        case GIMBAL_STATE_SWEEP: return "SWEEP";
        case GIMBAL_STATE_FAULT: return "FAULT";
        default: return "UNKNOWN";
    }
}

static void normalize_console_line(char *line)
{
    char *read_cursor;
    char *write_cursor;
    char *end;

    if (line == NULL)
    {
        return;
    }

    read_cursor = line;
    while ((*read_cursor != '\0') &&
           (isspace((unsigned char)*read_cursor) != 0))
    {
        read_cursor++;
    }

    write_cursor = line;
    while (*read_cursor != '\0')
    {
        unsigned char character = (unsigned char)*read_cursor++;
        if (isspace(character) != 0)
        {
            character = (unsigned char)' ';
        }
        else
        {
            character = (unsigned char)toupper(character);
        }
        *write_cursor++ = (char)character;
    }
    *write_cursor = '\0';

    end = write_cursor;
    while ((end > line) && (end[-1] == ' '))
    {
        *--end = '\0';
    }
}

static uint8_t motion_active(void)
{
    return ((s_state == GIMBAL_STATE_HOLD) ||
            (s_state == GIMBAL_STATE_STEP) ||
            (s_state == GIMBAL_STATE_SWEEP)) ? 1U : 0U;
}

static void enter_stopped_state(GimbalFault fault, uint32_t now_ms)
{
    power_output_force_off();
    s_fault = fault;
    s_state = (fault == GIMBAL_FAULT_NONE) ?
              GIMBAL_STATE_SAFE_IDLE : GIMBAL_STATE_FAULT;
    s_state_start_ms = now_ms;
    s_arm_deadline_ms = 0U;
    s_disable_burst = GIMBAL_DISABLE_BURST_COUNT;
    s_next_motor_tx_ms = now_ms;
    g_gimbal_debug.arm_key = 0U;
    s_zero_referenced_motion = 0U;
}

static uint8_t feedback_ready(uint32_t now_ms)
{
    const Dm4310Status *motor = dm4310_status();
    return ((motor->online != 0U) &&
            ((uint32_t)(now_ms - motor->last_rx_ms) <=
             GIMBAL_FEEDBACK_TIMEOUT_MS)) ? 1U : 0U;
}

static uint8_t arm_is_valid(uint32_t now_ms)
{
    if (s_arm_deadline_ms == 0U)
    {
        return 0U;
    }
    return (time_reached(now_ms, s_arm_deadline_ms) == 0U) ? 1U : 0U;
}

static void arm_for_motion(uint32_t now_ms)
{
    s_arm_deadline_ms = now_ms + GIMBAL_ARM_WINDOW_MS;
}

static uint8_t start_motion(GimbalState requested_state,
                            int32_t tenths_degree,
                            uint8_t use_level_zero,
                            uint32_t now_ms)
{
    const Dm4310Status *motor = dm4310_status();
    float requested_offset_rad;
    float maximum_rad = GIMBAL_DESKTOP_MAX_ANGLE_DEG * DEG_TO_RAD;

    if ((power_output_is_ready() == 0U) ||
        (arm_is_valid(now_ms) == 0U) ||
        (feedback_ready(now_ms) == 0U) ||
        ((use_level_zero != 0U) && (s_level_zero_valid == 0U)))
    {
        return 0U;
    }

    requested_offset_rad =
        ((float)tenths_degree * 0.1f) * DEG_TO_RAD;
    requested_offset_rad =
        clamp_float(requested_offset_rad, -maximum_rad, maximum_rad);

    s_neutral_rad = (use_level_zero != 0U) ?
                    s_level_zero_rad : motor->position_rad;
    s_command_rad = motor->position_rad;
    s_sweep_amplitude_rad = absolute_float(requested_offset_rad);
    s_sweep_direction = 1;

    if (requested_state == GIMBAL_STATE_HOLD)
    {
        s_requested_rad = s_neutral_rad;
    }
    else if (requested_state == GIMBAL_STATE_STEP)
    {
        s_requested_rad = s_neutral_rad + requested_offset_rad;
    }
    else
    {
        if (s_sweep_amplitude_rad < (0.1f * DEG_TO_RAD))
        {
            s_sweep_amplitude_rad = 0.1f * DEG_TO_RAD;
        }
        s_requested_rad = s_neutral_rad + s_sweep_amplitude_rad;
    }

    if (dm4310_enable() != HAL_OK)
    {
        enter_stopped_state(GIMBAL_FAULT_CAN_TX, now_ms);
        return 0U;
    }

    s_state = requested_state;
    s_zero_referenced_motion = use_level_zero;
    s_post_jog_disable_deadline_ms = 0U;
    s_fault = GIMBAL_FAULT_NONE;
    s_state_start_ms = now_ms;
    s_next_motor_tx_ms = now_ms;
    s_arm_deadline_ms = 0U;
    return 1U;
}

static uint8_t capture_level_zero(uint32_t now_ms)
{
    const Dm4310Status *motor = dm4310_status();

    if ((s_state != GIMBAL_STATE_OBSERVE) ||
        (feedback_ready(now_ms) == 0U) ||
        (motor->error != 0U))
    {
        return 0U;
    }

    s_level_zero_rad = motor->position_rad;
    s_level_zero_valid = 1U;
    s_neutral_rad = s_level_zero_rad;
    s_requested_rad = s_level_zero_rad;
    s_command_rad = s_level_zero_rad;
    s_arm_deadline_ms = 0U;
    return 1U;
}

static void process_request(GimbalRequest request,
                            int32_t tenths_degree,
                            uint8_t debugger_arm,
                            uint32_t now_ms)
{
    if (debugger_arm != 0U)
    {
        arm_for_motion(now_ms);
    }

    switch (request)
    {
        case GIMBAL_REQUEST_NONE:
            break;

        case GIMBAL_REQUEST_STOP:
            enter_stopped_state(GIMBAL_FAULT_NONE, now_ms);
            break;

        case GIMBAL_REQUEST_OBSERVE:
            if ((motion_active() == 0U) &&
                (power_output_is_ready() != 0U))
            {
                s_state = GIMBAL_STATE_OBSERVE;
                s_fault = GIMBAL_FAULT_NONE;
                s_state_start_ms = now_ms;
                s_next_motor_tx_ms = now_ms;
                s_arm_deadline_ms = 0U;
            }
            break;

        case GIMBAL_REQUEST_HOLD:
            (void)start_motion(GIMBAL_STATE_HOLD, 0, 0U, now_ms);
            break;

        case GIMBAL_REQUEST_STEP:
            (void)start_motion(GIMBAL_STATE_STEP,
                               tenths_degree,
                               0U,
                               now_ms);
            break;

        case GIMBAL_REQUEST_SWEEP:
            (void)start_motion(GIMBAL_STATE_SWEEP,
                               tenths_degree,
                               0U,
                               now_ms);
            break;

        case GIMBAL_REQUEST_CLEAR_FAULT:
            if (motion_active() == 0U)
            {
                enter_stopped_state(GIMBAL_FAULT_NONE, now_ms);
            }
            break;

        default:
            if (motion_active() == 0U)
            {
                s_fault = GIMBAL_FAULT_BAD_COMMAND;
            }
            break;
    }
}

static int32_t parse_tenths_degree(const char *text)
{
    double degrees;
    char *end;

    if (text == NULL)
    {
        return 0;
    }

    degrees = strtod(text, &end);
    if (end == text)
    {
        return 0;
    }
    if (degrees > GIMBAL_DESKTOP_MAX_ANGLE_DEG)
    {
        degrees = GIMBAL_DESKTOP_MAX_ANGLE_DEG;
    }
    if (degrees < -GIMBAL_DESKTOP_MAX_ANGLE_DEG)
    {
        degrees = -GIMBAL_DESKTOP_MAX_ANGLE_DEG;
    }
    return (int32_t)(degrees * 10.0);
}

#if GIMBAL_ENABLE_MANUAL_CALRUN
static uint8_t parse_calrun_argument(const char *text,
                                     int32_t *tenths_degree)
{
    const char *cursor;
    char *end;
    double degrees;

    if ((text == NULL) || (tenths_degree == NULL) ||
        (strncmp(text, "4310", 4U) != 0))
    {
        return 0U;
    }

    cursor = text + 4;
    if (*cursor != ' ')
    {
        return 0U;
    }
    while (*cursor == ' ')
    {
        cursor++;
    }

    degrees = strtod(cursor, &end);
    if ((end == cursor) || (*end != '\0') ||
        (degrees < 0.1) ||
        (degrees > (double)GIMBAL_DESKTOP_MAX_ANGLE_DEG))
    {
        return 0U;
    }

    *tenths_degree = (int32_t)((degrees * 10.0) + 0.5);
    return 1U;
}

static uint8_t calrun_begin(int32_t amplitude_tenths_degree,
                            uint32_t now_ms)
{
    if ((s_calrun_phase != CALRUN_IDLE) ||
        (s_state != GIMBAL_STATE_SAFE_IDLE) ||
        (s_fault != GIMBAL_FAULT_NONE) ||
        (s_power_output_enabled != 0U))
    {
        return 0U;
    }

    if ((arm_power_output(now_ms) == 0U) ||
        (power_output_enable(now_ms) == 0U))
    {
        enter_stopped_state(GIMBAL_FAULT_BAD_COMMAND, now_ms);
        return 0U;
    }

    s_calrun_amplitude_tenths_deg = amplitude_tenths_degree;
    s_calrun_phase = CALRUN_WAIT_READY;
    s_calrun_deadline_ms = now_ms + GIMBAL_CALRUN_PREP_TIMEOUT_MS;
    return 1U;
}
#endif

static uint8_t calrun_start_leg(int32_t tenths_degree,
                                CalRunPhase phase,
                                uint32_t now_ms)
{
    const Dm4310Status *motor = dm4310_status();

    arm_for_motion(now_ms);
    if (start_motion(GIMBAL_STATE_STEP,
                     tenths_degree,
                     1U,
                     now_ms) == 0U)
    {
        return 0U;
    }

    s_calrun_phase = phase;
    (void)usb_console_printf(
        "CALRUN LEG=%lu FROM=%ldmrad Z=%ldmrad TARGET=%ldmrad\r\n",
        (unsigned long)phase,
        (long)(motor->position_rad * 1000.0f),
        (long)(s_level_zero_rad * 1000.0f),
        (long)(s_requested_rad * 1000.0f));
    return 1U;
}

static uint8_t calrun_leg_is_finished(uint32_t now_ms)
{
    const Dm4310Status *motor = dm4310_status();

    return ((s_state == GIMBAL_STATE_OBSERVE) &&
            (s_zero_referenced_motion == 0U) &&
            (s_post_jog_disable_deadline_ms == 0U) &&
            (feedback_ready(now_ms) != 0U) &&
            (motor->error == 0U)) ? 1U : 0U;
}

static void run_calrun(uint32_t now_ms)
{
    const Dm4310Status *motor = dm4310_status();

    switch (s_calrun_phase)
    {
        case CALRUN_IDLE:
            break;

        case CALRUN_WAIT_READY:
            if (time_reached(now_ms, s_calrun_deadline_ms) != 0U)
            {
                (void)usb_console_write(
                    "CALRUN ABORT: no motor feedback in 15 s; "
                    "OUT1 OFF, SAFE_IDLE\r\n");
                enter_stopped_state(GIMBAL_FAULT_NONE, now_ms);
                break;
            }

            if (power_output_is_ready() == 0U)
            {
                break;
            }

            /*
             * The initial five-frame burst can finish before a cold DM4310
             * is ready to answer. Keep sending the same torque-disable frame
             * used by OBSERVE so startup can never deadlock waiting for a
             * reply while the drive remains explicitly disabled.
             */
            if (time_reached(now_ms, s_next_motor_tx_ms) != 0U)
            {
                if (dm4310_query() != HAL_OK)
                {
                    (void)usb_console_write(
                        "CALRUN ABORT: CAN transmit failed\r\n");
                    enter_stopped_state(GIMBAL_FAULT_CAN_TX, now_ms);
                    break;
                }
                s_next_motor_tx_ms =
                    now_ms + GIMBAL_OBSERVE_QUERY_PERIOD_MS;
            }

            if ((feedback_ready(now_ms) != 0U) &&
                (motor->error != 0U) &&
                (motor->error != 1U))
            {
                (void)usb_console_printf(
                    "CALRUN ABORT: motor ERR=0x%lX\r\n",
                    (unsigned long)motor->error);
                enter_stopped_state(GIMBAL_FAULT_MOTOR_REPORTED, now_ms);
                break;
            }

            if ((feedback_ready(now_ms) != 0U) && (motor->error == 0U))
            {
                s_state = GIMBAL_STATE_OBSERVE;
                s_state_start_ms = now_ms;
                s_next_motor_tx_ms = now_ms;
                s_calrun_phase = CALRUN_COUNTDOWN;
                s_calrun_deadline_ms =
                    now_ms + GIMBAL_CALRUN_COUNTDOWN_MS;
                (void)usb_console_write(
                    "CALRUN READY: motion starts in 3 s; send STOP to abort\r\n");
            }
            break;

        case CALRUN_COUNTDOWN:
            if (time_reached(now_ms, s_calrun_deadline_ms) == 0U)
            {
                break;
            }
            if ((capture_level_zero(now_ms) == 0U) ||
                (calrun_start_leg(s_calrun_amplitude_tenths_deg,
                                  CALRUN_POSITIVE,
                                  now_ms) == 0U))
            {
                (void)usb_console_write(
                    "CALRUN ABORT: zero/positive start failed\r\n");
                enter_stopped_state(GIMBAL_FAULT_FEEDBACK_TIMEOUT, now_ms);
            }
            break;

        case CALRUN_POSITIVE:
            if ((calrun_leg_is_finished(now_ms) != 0U) &&
                (calrun_start_leg(0,
                                  CALRUN_RETURN_FROM_POSITIVE,
                                  now_ms) == 0U))
            {
                (void)usb_console_write(
                    "CALRUN ABORT: first return failed\r\n");
                enter_stopped_state(GIMBAL_FAULT_FEEDBACK_TIMEOUT, now_ms);
            }
            break;

        case CALRUN_RETURN_FROM_POSITIVE:
            if ((calrun_leg_is_finished(now_ms) != 0U) &&
                (calrun_start_leg(-s_calrun_amplitude_tenths_deg,
                                  CALRUN_NEGATIVE,
                                  now_ms) == 0U))
            {
                (void)usb_console_write(
                    "CALRUN ABORT: negative start failed\r\n");
                enter_stopped_state(GIMBAL_FAULT_FEEDBACK_TIMEOUT, now_ms);
            }
            break;

        case CALRUN_NEGATIVE:
            if ((calrun_leg_is_finished(now_ms) != 0U) &&
                (calrun_start_leg(0,
                                  CALRUN_FINAL_RETURN,
                                  now_ms) == 0U))
            {
                (void)usb_console_write(
                    "CALRUN ABORT: final return failed\r\n");
                enter_stopped_state(GIMBAL_FAULT_FEEDBACK_TIMEOUT, now_ms);
            }
            break;

        case CALRUN_FINAL_RETURN:
            if (calrun_leg_is_finished(now_ms) != 0U)
            {
                (void)usb_console_printf(
                    "CALRUN COMPLETE P=%ldmrad OFF=%ldmrad; OUT1 OFF\r\n",
                    (long)(motor->position_rad * 1000.0f),
                    (long)((motor->position_rad - s_level_zero_rad) *
                           1000.0f));
                enter_stopped_state(GIMBAL_FAULT_NONE, now_ms);
            }
            break;

        default:
            (void)usb_console_write("CALRUN ABORT: invalid phase\r\n");
            enter_stopped_state(GIMBAL_FAULT_BAD_COMMAND, now_ms);
            break;
    }
}

static void send_status(uint32_t now_ms)
{
    const Dm4310Status *motor = dm4310_status();
    int32_t position_mrad = (int32_t)(motor->position_rad * 1000.0f);
    int32_t velocity_mrad_s =
        (int32_t)(motor->velocity_rad_s * 1000.0f);
    int32_t target_mrad = (int32_t)(s_command_rad * 1000.0f);
    int32_t zero_mrad = (int32_t)(s_level_zero_rad * 1000.0f);
    int32_t offset_mrad =
        (s_level_zero_valid != 0U) ?
        (int32_t)((motor->position_rad - s_level_zero_rad) * 1000.0f) : 0;
    uint32_t age = (motor->rx_count == 0U) ?
                   0xFFFFFFFFUL : (uint32_t)(now_ms - motor->last_rx_ms);
    uint32_t power_arm_remaining =
        (power_arm_is_valid(now_ms) != 0U) ?
        (uint32_t)(s_power_arm_deadline_ms - now_ms) : 0U;
    uint32_t power_on_remaining =
        ((s_power_output_enabled != 0U) &&
         (time_reached(now_ms, s_power_off_deadline_ms) == 0U)) ?
        (uint32_t)(s_power_off_deadline_ms - now_ms) : 0U;

    (void)usb_console_printf(
        "STATE=%s FAULT=%lu ONLINE=%u ERR=0x%lX "
        "P=%ldmrad V=%ldmrad/s CMD=%ldmrad AGE=%lums "
        "RX=%lu TX=%lu TXERR=%lu PWR=%u PWRARM=%lums PWRLEFT=%lums "
        "CAL=%lu ZVALID=%u Z=%ldmrad OFF=%ldmrad\r\n",
        state_name(s_state),
        (unsigned long)s_fault,
        (unsigned int)motor->online,
        (unsigned long)motor->error,
        (long)position_mrad,
        (long)velocity_mrad_s,
        (long)target_mrad,
        (unsigned long)age,
        (unsigned long)motor->rx_count,
        (unsigned long)motor->tx_count,
        (unsigned long)motor->tx_error_count,
        (unsigned int)s_power_output_enabled,
        (unsigned long)power_arm_remaining,
        (unsigned long)power_on_remaining,
        (unsigned long)s_calrun_phase,
        (unsigned int)s_level_zero_valid,
        (long)zero_mrad,
        (long)offset_mrad);
}

static void process_console(uint32_t now_ms)
{
    char line[96];
    char *argument;

    while (usb_console_get_line(line, sizeof(line)) != 0U)
    {
        normalize_console_line(line);

        argument = strchr(line, ' ');
        if (argument != NULL)
        {
            *argument++ = '\0';
            while (*argument == ' ')
            {
                argument++;
            }
        }

        if ((s_calrun_phase != CALRUN_IDLE) &&
            (strcmp(line, "PING") != 0) &&
            (strcmp(line, "HELP") != 0) &&
            (strcmp(line, "STATUS") != 0) &&
            (strcmp(line, "STOP") != 0))
        {
            (void)usb_console_write(
                "DENIED: CALRUN active; only STATUS or STOP allowed\r\n");
            continue;
        }

        if (strcmp(line, "PING") == 0)
        {
            (void)usb_console_printf("PONG BUILD=%lu DESKTOP=%u\r\n",
                                     (unsigned long)GIMBAL_BUILD_ID,
                                     (unsigned int)GIMBAL_DESKTOP_BUILD);
        }
        else if (strcmp(line, "HELP") == 0)
        {
            (void)usb_console_write(
                "PING | STATUS | OBSERVE | ARM | HOLD | "
                "STEP deg | SWEEP deg | ZERO | JOG deg | STOP | CLEAR\r\n"
                "PWRARM 4310 | PWRON | PWROFF | CALRUN 4310 deg\r\n"
                "ZERO requires OBSERVE; JOG requires ZERO then ARM.\r\n"
                "CALRUN is manual-only: auto power/+deg/0/-deg/0/power-off.\r\n"
                "OUT1 expires in 180 s; STOP/fault/reset turns it off.\r\n");
        }
        else if (strcmp(line, "STATUS") == 0)
        {
            send_status(now_ms);
        }
        else if (strcmp(line, "CALRUN") == 0)
        {
            int32_t amplitude_tenths_degree;
#if GIMBAL_ENABLE_MANUAL_CALRUN
            if ((parse_calrun_argument(argument,
                                       &amplitude_tenths_degree) != 0U) &&
                (calrun_begin(amplitude_tenths_degree, now_ms) != 0U))
            {
                (void)usb_console_printf(
                    "CALRUN START amplitude=%ld.%lddeg; "
                    "OUT1 ON, keep clear\r\n",
                    (long)(amplitude_tenths_degree / 10),
                    (long)(amplitude_tenths_degree % 10));
            }
            else
            {
                (void)usb_console_write(
                    "DENIED: use CALRUN 4310 deg (0.1..10) from safe idle\r\n");
            }
#else
            (void)amplitude_tenths_degree;
            (void)usb_console_write(
                "DENIED: CALRUN disabled in this build\r\n");
#endif
        }
        else if (strcmp(line, "OBSERVE") == 0)
        {
            if (power_output_is_ready() != 0U)
            {
                process_request(GIMBAL_REQUEST_OBSERVE, 0, 0U, now_ms);
                (void)usb_console_write(
                    "OK OBSERVE (motor torque not enabled)\r\n");
            }
            else
            {
                (void)usb_console_write(
                    "DENIED: OUT1 off or startup disable burst pending\r\n");
            }
        }
        else if (strcmp(line, "PWRARM") == 0)
        {
            if ((argument != NULL) &&
                (strcmp(argument, "4310") == 0) &&
                (arm_power_output(now_ms) != 0U))
            {
                (void)usb_console_write(
                    "OK OUT1 ARMED FOR 3000 ms; send PWRON\r\n");
            }
            else
            {
                (void)usb_console_write(
                    "DENIED: use PWRARM 4310 from safe idle\r\n");
            }
        }
        else if (strcmp(line, "PWRON") == 0)
        {
            if (power_output_enable(now_ms) != 0U)
            {
                (void)usb_console_write(
                    "OK OUT1 ON FOR 180000 ms; wait before OBSERVE\r\n");
            }
            else
            {
                (void)usb_console_write(
                    "DENIED: PWRARM 4310 required within 3 s\r\n");
            }
        }
        else if (strcmp(line, "PWROFF") == 0)
        {
            enter_stopped_state(GIMBAL_FAULT_NONE, now_ms);
            (void)usb_console_write("OK OUT1 OFF; MOTOR UNPOWERED\r\n");
        }
        else if (strcmp(line, "ARM") == 0)
        {
            if (feedback_ready(now_ms) != 0U)
            {
                arm_for_motion(now_ms);
                (void)usb_console_write("OK ARMED FOR 3000 ms\r\n");
            }
            else
            {
                (void)usb_console_write(
                    "DENIED: no fresh motor feedback; run OBSERVE first\r\n");
            }
        }
        else if (strcmp(line, "HOLD") == 0)
        {
            if (start_motion(GIMBAL_STATE_HOLD, 0, 0U, now_ms) != 0U)
            {
                (void)usb_console_write("OK HOLD (auto-stop 15 s)\r\n");
            }
            else
            {
                (void)usb_console_write(
                    "DENIED: ARM and fresh feedback required\r\n");
            }
        }
        else if (strcmp(line, "STEP") == 0)
        {
            int32_t value = parse_tenths_degree(argument);
            if (start_motion(GIMBAL_STATE_STEP, value, 0U, now_ms) != 0U)
            {
                (void)usb_console_write("OK STEP (auto-stop 3 s)\r\n");
            }
            else
            {
                (void)usb_console_write(
                    "DENIED: ARM and fresh feedback required\r\n");
            }
        }
        else if (strcmp(line, "SWEEP") == 0)
        {
            int32_t value = parse_tenths_degree(argument);
            if (value < 0)
            {
                value = -value;
            }
            if (start_motion(GIMBAL_STATE_SWEEP, value, 0U, now_ms) != 0U)
            {
                (void)usb_console_write("OK SWEEP (auto-stop 6 s)\r\n");
            }
            else
            {
                (void)usb_console_write(
                    "DENIED: ARM and fresh feedback required\r\n");
            }
        }
        else if (strcmp(line, "ZERO") == 0)
        {
            if (capture_level_zero(now_ms) != 0U)
            {
                (void)usb_console_printf(
                    "OK LEVEL ZERO P=%ldmrad; send ARM then JOG deg\r\n",
                    (long)(s_level_zero_rad * 1000.0f));
            }
            else
            {
                (void)usb_console_write(
                    "DENIED: ZERO requires OBSERVE and fresh feedback\r\n");
            }
        }
        else if (strcmp(line, "JOG") == 0)
        {
            int32_t value = parse_tenths_degree(argument);
            if ((argument != NULL) &&
                (start_motion(GIMBAL_STATE_STEP,
                              value,
                              1U,
                              now_ms) != 0U))
            {
                const Dm4310Status *motor = dm4310_status();
                (void)usb_console_printf(
                    "OK JOG FROM=%ldmrad Z=%ldmrad TARGET=%ldmrad "
                    "(3 s, then disabled OBSERVE)\r\n",
                    (long)(motor->position_rad * 1000.0f),
                    (long)(s_level_zero_rad * 1000.0f),
                    (long)(s_requested_rad * 1000.0f));
            }
            else
            {
                (void)usb_console_write(
                    "DENIED: ZERO, ARM and fresh feedback required\r\n");
            }
        }
        else if (strcmp(line, "STOP") == 0)
        {
            enter_stopped_state(GIMBAL_FAULT_NONE, now_ms);
            (void)usb_console_write("OK STOPPED/DISABLED; OUT1 OFF\r\n");
        }
        else if (strcmp(line, "CLEAR") == 0)
        {
            process_request(GIMBAL_REQUEST_CLEAR_FAULT, 0, 0U, now_ms);
            (void)usb_console_write("OK FAULT CLEARED; MOTOR DISABLED\r\n");
        }
        else
        {
            (void)usb_console_write("ERR unknown command; send HELP\r\n");
        }
    }
}

static void run_safe_transmit(uint32_t now_ms)
{
    if ((s_disable_burst > 0U) &&
        (time_reached(now_ms, s_next_motor_tx_ms) != 0U))
    {
        if (dm4310_disable() == HAL_OK)
        {
            s_disable_burst--;
        }
        else if (s_power_output_enabled != 0U)
        {
            enter_stopped_state(GIMBAL_FAULT_CAN_TX, now_ms);
            return;
        }
        else
        {
            s_disable_burst--;
        }
        s_next_motor_tx_ms = now_ms + GIMBAL_MOTOR_COMMAND_PERIOD_MS;
    }
}

static void run_observe(uint32_t now_ms)
{
    const Dm4310Status *motor = dm4310_status();
    uint8_t post_jog_settling =
        ((s_post_jog_disable_deadline_ms != 0U) &&
         (time_reached(now_ms,
                       s_post_jog_disable_deadline_ms) == 0U)) ? 1U : 0U;

    /*
     * OBSERVE is a torque-disabled state. If fresh feedback says the drive is
     * enabled (state 1) or reports any fault, remove OUT1 power immediately.
     * This also guards against a drive that boots into an unexpected state.
     */
    if ((feedback_ready(now_ms) != 0U) &&
        (motor->error != 0U) &&
        !((motor->error == 1U) && (post_jog_settling != 0U)))
    {
        enter_stopped_state(GIMBAL_FAULT_MOTOR_REPORTED, now_ms);
        return;
    }

    if ((feedback_ready(now_ms) != 0U) && (motor->error == 0U))
    {
        s_post_jog_disable_deadline_ms = 0U;
    }

    if (time_reached(now_ms, s_next_motor_tx_ms) != 0U)
    {
        (void)dm4310_query();
        s_next_motor_tx_ms = now_ms + GIMBAL_OBSERVE_QUERY_PERIOD_MS;
    }
}

static void run_motion(uint32_t now_ms)
{
    const Dm4310Status *motor = dm4310_status();
    uint32_t elapsed = now_ms - s_state_start_ms;
    uint32_t timeout_ms = GIMBAL_HOLD_TIMEOUT_MS;
    float maximum_rad = GIMBAL_DESKTOP_MAX_ANGLE_DEG * DEG_TO_RAD;
    float maximum_step =
        GIMBAL_DESKTOP_MAX_SLEW_RAD_S *
        ((float)GIMBAL_MOTOR_COMMAND_PERIOD_MS / 1000.0f);
    float delta;

    if (s_state == GIMBAL_STATE_STEP)
    {
        timeout_ms = GIMBAL_STEP_TIMEOUT_MS;
    }
    else if (s_state == GIMBAL_STATE_SWEEP)
    {
        timeout_ms = GIMBAL_SWEEP_TIMEOUT_MS;
    }

    if (elapsed >= timeout_ms)
    {
        if (s_zero_referenced_motion != 0U)
        {
            int32_t position_mrad =
                (int32_t)(motor->position_rad * 1000.0f);
            int32_t offset_mrad =
                (int32_t)((motor->position_rad - s_level_zero_rad) *
                          1000.0f);

            if (dm4310_disable() != HAL_OK)
            {
                enter_stopped_state(GIMBAL_FAULT_CAN_TX, now_ms);
                return;
            }

            s_zero_referenced_motion = 0U;
            s_state = GIMBAL_STATE_OBSERVE;
            s_state_start_ms = now_ms;
            s_arm_deadline_ms = 0U;
            s_post_jog_disable_deadline_ms =
                now_ms + GIMBAL_POST_JOG_DISABLE_SETTLE_MS;
            s_next_motor_tx_ms = now_ms + GIMBAL_OBSERVE_QUERY_PERIOD_MS;
            (void)usb_console_printf(
                "JOG DONE P=%ldmrad OFF=%ldmrad; "
                "TORQUE OFF, OBSERVE, OUT1 ON\r\n",
                (long)position_mrad,
                (long)offset_mrad);
            return;
        }

        enter_stopped_state(GIMBAL_FAULT_NONE, now_ms);
        return;
    }

    if (feedback_ready(now_ms) == 0U)
    {
        enter_stopped_state(GIMBAL_FAULT_FEEDBACK_TIMEOUT, now_ms);
        return;
    }

    if ((motor->error != 0U) && (motor->error != 1U))
    {
        enter_stopped_state(GIMBAL_FAULT_MOTOR_REPORTED, now_ms);
        return;
    }

    if (time_reached(now_ms, s_next_motor_tx_ms) == 0U)
    {
        return;
    }

    if (s_state == GIMBAL_STATE_SWEEP)
    {
        if ((s_sweep_direction > 0) &&
            (s_command_rad >=
             (s_neutral_rad + s_sweep_amplitude_rad - maximum_step)))
        {
            s_sweep_direction = -1;
        }
        else if ((s_sweep_direction < 0) &&
                 (s_command_rad <=
                  (s_neutral_rad - s_sweep_amplitude_rad + maximum_step)))
        {
            s_sweep_direction = 1;
        }
        s_requested_rad = s_neutral_rad +
                          ((float)s_sweep_direction *
                           s_sweep_amplitude_rad);
    }

    s_requested_rad = clamp_float(s_requested_rad,
                                  s_neutral_rad - maximum_rad,
                                  s_neutral_rad + maximum_rad);
    delta = s_requested_rad - s_command_rad;
    if (delta > maximum_step)
    {
        delta = maximum_step;
    }
    else if (delta < -maximum_step)
    {
        delta = -maximum_step;
    }
    s_command_rad += delta;

    if (dm4310_command_position_speed(
            s_command_rad,
            GIMBAL_DESKTOP_MAX_SLEW_RAD_S) != HAL_OK)
    {
        enter_stopped_state(GIMBAL_FAULT_CAN_TX, now_ms);
        return;
    }
    s_next_motor_tx_ms = now_ms + GIMBAL_MOTOR_COMMAND_PERIOD_MS;
}

static void update_debug(uint32_t now_ms)
{
    const Dm4310Status *motor = dm4310_status();

    g_gimbal_debug.build_id = GIMBAL_BUILD_ID;
    g_gimbal_debug.uptime_ms = now_ms;
    g_gimbal_debug.state = (uint32_t)s_state;
    g_gimbal_debug.fault = (uint32_t)s_fault;
    g_gimbal_debug.state_elapsed_ms = now_ms - s_state_start_ms;
    g_gimbal_debug.arm_remaining_ms =
        (arm_is_valid(now_ms) != 0U) ?
        (uint32_t)(s_arm_deadline_ms - now_ms) : 0U;
    g_gimbal_debug.power_output_enabled = s_power_output_enabled;
    g_gimbal_debug.power_arm_remaining_ms =
        (power_arm_is_valid(now_ms) != 0U) ?
        (uint32_t)(s_power_arm_deadline_ms - now_ms) : 0U;
    g_gimbal_debug.power_on_remaining_ms =
        ((s_power_output_enabled != 0U) &&
         (time_reached(now_ms, s_power_off_deadline_ms) == 0U)) ?
        (uint32_t)(s_power_off_deadline_ms - now_ms) : 0U;
    g_gimbal_debug.calrun_phase = (uint32_t)s_calrun_phase;

    g_gimbal_debug.level_zero_valid = s_level_zero_valid;
    g_gimbal_debug.level_zero_position_rad = s_level_zero_rad;
    g_gimbal_debug.motor_offset_from_level_rad =
        (s_level_zero_valid != 0U) ?
        (motor->position_rad - s_level_zero_rad) : 0.0f;
    g_gimbal_debug.neutral_position_rad = s_neutral_rad;
    g_gimbal_debug.requested_position_rad = s_requested_rad;
    g_gimbal_debug.command_position_rad = s_command_rad;
    g_gimbal_debug.feedback_position_rad = motor->position_rad;
    g_gimbal_debug.feedback_velocity_rad_s = motor->velocity_rad_s;
    g_gimbal_debug.feedback_torque_nm = motor->torque_nm;
    g_gimbal_debug.feedback_age_ms =
        (motor->rx_count == 0U) ?
        0xFFFFFFFFUL : (uint32_t)(now_ms - motor->last_rx_ms);
    g_gimbal_debug.motor_error = motor->error;
    g_gimbal_debug.motor_mos_temperature_c =
        motor->mos_temperature_c;
    g_gimbal_debug.motor_rotor_temperature_c =
        motor->rotor_temperature_c;

    g_gimbal_debug.can_rx_count = motor->rx_count;
    g_gimbal_debug.can_tx_count = motor->tx_count;
    g_gimbal_debug.can_tx_error_count = motor->tx_error_count;
    g_gimbal_debug.usb_rx_bytes = usb_console_rx_bytes();
    g_gimbal_debug.usb_rx_overflow = usb_console_rx_overflow();
    g_gimbal_debug.usb_tx_drop = usb_console_tx_drop();

    if (s_vision_received != 0U)
    {
        g_gimbal_debug.vision_position_um = s_vision.position_um;
        g_gimbal_debug.vision_velocity_um_s = s_vision.velocity_um_s;
        g_gimbal_debug.vision_age_ms =
            (uint32_t)(now_ms - s_vision.receive_time_ms);
        g_gimbal_debug.vision_flags = s_vision.flags;
    }
    else
    {
        g_gimbal_debug.vision_age_ms = 0xFFFFFFFFUL;
    }
    g_gimbal_debug.vision_closed_loop_enabled = 0U;
}

void gimbal_app_init(uint32_t now_ms)
{
    const Dm4310Status *motor;

    memset((void *)&g_gimbal_debug, 0, sizeof(g_gimbal_debug));
    memset(&s_vision, 0, sizeof(s_vision));
    s_vision_received = 0U;
    s_state = GIMBAL_STATE_BOOT;
    s_fault = GIMBAL_FAULT_NONE;
    s_state_start_ms = now_ms;
    s_arm_deadline_ms = 0U;
    s_power_arm_deadline_ms = 0U;
    s_power_off_deadline_ms = 0U;
    s_post_jog_disable_deadline_ms = 0U;
    s_power_output_enabled = 0U;
    s_level_zero_valid = 0U;
    s_zero_referenced_motion = 0U;
    s_calrun_phase = CALRUN_IDLE;
    s_calrun_deadline_ms = 0U;
    s_calrun_amplitude_tenths_deg = 0;
    s_level_zero_rad = 0.0f;
    power_output_force_off();
    s_neutral_rad = 0.0f;
    s_requested_rad = 0.0f;
    s_command_rad = 0.0f;

    dm4310_init(&hfdcan1, now_ms);
    motor = dm4310_status();
    if (motor->initialized == 0U)
    {
        enter_stopped_state(GIMBAL_FAULT_CAN_INIT, now_ms);
    }
    else
    {
        enter_stopped_state(GIMBAL_FAULT_NONE, now_ms);
    }
    update_debug(now_ms);
}

void gimbal_app_poll(uint32_t now_ms)
{
    uint32_t request;
    int32_t parameter;
    uint8_t debugger_arm;

    dm4310_poll(now_ms);
    process_console(now_ms);

    if ((s_power_output_enabled != 0U) &&
        (time_reached(now_ms, s_power_off_deadline_ms) != 0U))
    {
        enter_stopped_state(GIMBAL_FAULT_NONE, now_ms);
    }

    request = g_gimbal_debug.request;
    parameter = g_gimbal_debug.request_param_tenths_deg;
    debugger_arm =
        (g_gimbal_debug.arm_key == GIMBAL_DEBUG_ARM_KEY) ? 1U : 0U;
    if (s_calrun_phase != CALRUN_IDLE)
    {
        g_gimbal_debug.request = GIMBAL_REQUEST_NONE;
        g_gimbal_debug.arm_key = 0U;
        if (request == GIMBAL_REQUEST_STOP)
        {
            process_request(GIMBAL_REQUEST_STOP, 0, 0U, now_ms);
        }
    }
    else if (request != GIMBAL_REQUEST_NONE)
    {
        g_gimbal_debug.request = GIMBAL_REQUEST_NONE;
        g_gimbal_debug.arm_key = 0U;
        process_request((GimbalRequest)request,
                        parameter,
                        debugger_arm,
                        now_ms);
    }
    else if (g_gimbal_debug.arm_key == GIMBAL_DEBUG_ARM_KEY)
    {
        /*
         * Ozone Watch writes are not atomic as a group.  Accept the key by
         * itself and retain the resulting three-second arm window so the
         * operator can write request afterwards.
         */
        arm_for_motion(now_ms);
        g_gimbal_debug.arm_key = 0U;
    }
    else if (g_gimbal_debug.arm_key != 0U)
    {
        /* A key written without a request is never retained. */
        g_gimbal_debug.arm_key = 0U;
    }

    run_calrun(now_ms);

    if (motion_active() != 0U)
    {
        run_motion(now_ms);
    }
    else if (s_state == GIMBAL_STATE_OBSERVE)
    {
        run_observe(now_ms);
    }
    else
    {
        run_safe_transmit(now_ms);
    }

    update_debug(now_ms);
}

void gimbal_app_on_vision_sample(const VisionSample *sample)
{
    if (sample == NULL)
    {
        return;
    }
    s_vision = *sample;
    s_vision_received = 1U;
}
