#ifndef GIMBAL_CONFIG_H
#define GIMBAL_CONFIG_H

/*
 * Desktop-safe build for DAMIAO DM-MC-Board02 + DM-J4310-2EC V1.2.
 *
 * Verified project settings from the motor assistant:
 *   supply: 24 V nominal (6S battery)
 *   motor CAN ID: 0x01
 *   motor Master ID / feedback CAN ID: 0xF1
 *   control mode: position-speed mode
 *   CAN: classic standard frame, 1 Mbit/s
 *
 * Build 2026072903 adds an explicitly armed, time-limited OUT1 bench-power
 * path. Build 2026072904 makes torque-disabled OBSERVE repeat the selected
 * mode's disable frame so the DM4310 returns continuous feedback. Build
 * Build 2026072905 extends guarded OUT1 power from 30 s to 90 s for parameter
 * setup. Build 2026072906 extends HOLD auto-stop from 5 s to 15 s for
 * operator observation. Build 2026072907 raises the bounded desktop relative
 * angle from +/-3 degrees to +/-10 degrees after stable HOLD verification;
 * every immediate cutoff path and the 0.20 rad/s slew limit remain unchanged.
 * Build 2026073001 adds installed-mechanism ZERO and zero-referenced JOG
 * commands without increasing any motion, speed, time, or power limit.
 * Build 2026073002 keeps OUT1 on but explicitly disables torque and returns
 * to OBSERVE after JOG, preserving one motor coordinate frame for
 * +offset/zero/-offset calibration. STOP/fault/reset and the 90 s power
 * timeout still remove OUT1 power.
 * Build 2026073003 allows 200 ms for enabled feedback to clear after the
 * explicit post-JOG disable and extends the guarded calibration power window
 * to 180 s. Motion bounds and immediate STOP/fault cutoffs are unchanged.
 * Build 2026073004 adds one explicitly named manual-only CALRUN command for
 * the complete +angle/zero/-angle/zero installed test. Disable
 * GIMBAL_ENABLE_MANUAL_CALRUN before any vehicle build.
 */

#define GIMBAL_BUILD_ID                    2026073004UL
#define GIMBAL_DESKTOP_BUILD               1U
#ifndef GIMBAL_ENABLE_MANUAL_CALRUN
#define GIMBAL_ENABLE_MANUAL_CALRUN         1U
#endif

#define DM4310_MOTOR_CAN_ID                0x01U
#define DM4310_MASTER_CAN_ID               0xF1U
#define DM4310_POSITION_SPEED_TX_ID         (0x100U + DM4310_MOTOR_CAN_ID)
#define DM4310_QUERY_TX_ID                  DM4310_MOTOR_CAN_ID

#define DM4310_PMAX_RAD                     12.5f
#define DM4310_VMAX_RAD_S                   30.0f
#define DM4310_TMAX_NM                      10.0f

#define GIMBAL_DESKTOP_MAX_ANGLE_DEG        10.0f
#define GIMBAL_DESKTOP_MAX_SLEW_RAD_S       0.20f
#define GIMBAL_MOTOR_COMMAND_PERIOD_MS      10U
#define GIMBAL_OBSERVE_QUERY_PERIOD_MS      20U
#define GIMBAL_FEEDBACK_TIMEOUT_MS          80U
#define GIMBAL_ARM_WINDOW_MS                3000U
#define GIMBAL_HOLD_TIMEOUT_MS              15000U
#define GIMBAL_STEP_TIMEOUT_MS              3000U
#define GIMBAL_SWEEP_TIMEOUT_MS             6000U
#define GIMBAL_DISABLE_BURST_COUNT          5U
#define GIMBAL_POWER_ARM_WINDOW_MS          3000U
#define GIMBAL_POWER_ON_TIMEOUT_MS          180000U
#define GIMBAL_POWER_STARTUP_SETTLE_MS      500U
#define GIMBAL_POST_JOG_DISABLE_SETTLE_MS   200U
#define GIMBAL_CALRUN_PREP_TIMEOUT_MS       5000U
#define GIMBAL_CALRUN_COUNTDOWN_MS          3000U

#define GIMBAL_VISION_STALE_MS              100U
#define GIMBAL_VISION_LOST_MS               500U

#define GIMBAL_DEBUG_ARM_KEY                0xA55A5AA5UL

/*
 * Frozen printed mechanism geometry. The installed hinge-to-follower
 * distance is deliberately not defined until the conflicting 236/248 mm
 * measurements are resolved. These constants are not used for motion yet.
 */
#define GIMBAL_CRANK_RADIUS_MM               15.45f
#define GIMBAL_FOLLOWER_DIAMETER_MM          12.0f
#define GIMBAL_PIPE_OUTER_DIAMETER_MM        20.0f

/*
 * OUT1/PC14 only. OUT2/PC13 remains permanently low/off.
 * High-active behavior follows the MC02 V1.1 schematic and still requires
 * the first unloaded voltage test before a motor is connected.
 */
#define GIMBAL_ALLOW_BOARD_POWER_OUTPUT     1U

#endif
