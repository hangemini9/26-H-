#ifndef GIMBAL_APP_H
#define GIMBAL_APP_H

#include "vision_link.h"
#include <stdint.h>

typedef enum
{
    GIMBAL_STATE_BOOT = 0,
    GIMBAL_STATE_SAFE_IDLE = 1,
    GIMBAL_STATE_OBSERVE = 2,
    GIMBAL_STATE_HOLD = 3,
    GIMBAL_STATE_STEP = 4,
    GIMBAL_STATE_SWEEP = 5,
    GIMBAL_STATE_FAULT = 6
} GimbalState;

typedef enum
{
    GIMBAL_FAULT_NONE = 0,
    GIMBAL_FAULT_CAN_INIT = 1,
    GIMBAL_FAULT_CAN_TX = 2,
    GIMBAL_FAULT_FEEDBACK_TIMEOUT = 3,
    GIMBAL_FAULT_MOTOR_REPORTED = 4,
    GIMBAL_FAULT_BAD_COMMAND = 5
} GimbalFault;

typedef enum
{
    GIMBAL_REQUEST_NONE = 0,
    GIMBAL_REQUEST_STOP = 1,
    GIMBAL_REQUEST_OBSERVE = 2,
    GIMBAL_REQUEST_HOLD = 3,
    GIMBAL_REQUEST_STEP = 4,
    GIMBAL_REQUEST_SWEEP = 5,
    GIMBAL_REQUEST_CLEAR_FAULT = 6
} GimbalRequest;

/*
 * One compact structure for SEGGER Ozone Watch.
 *
 * Safe debugger workflow:
 *   1. Set arm_key to GIMBAL_DEBUG_ARM_KEY.
 *   2. Set request_param_tenths_deg if STEP/SWEEP is requested.
 *   3. Set request last.
 *
 * The firmware consumes and clears both arm_key and request.  STOP and
 * OBSERVE never require arm_key.  Do not halt the CPU during powered motion.
 */
typedef struct
{
    volatile uint32_t build_id;
    volatile uint32_t uptime_ms;
    volatile uint32_t arm_key;
    volatile uint32_t request;
    volatile int32_t request_param_tenths_deg;

    volatile uint32_t state;
    volatile uint32_t fault;
    volatile uint32_t state_elapsed_ms;
    volatile uint32_t arm_remaining_ms;
    volatile uint32_t power_output_enabled;
    volatile uint32_t power_arm_remaining_ms;
    volatile uint32_t power_on_remaining_ms;
    volatile uint32_t calrun_phase;

    volatile uint32_t level_zero_valid;
    volatile float level_zero_position_rad;
    volatile float motor_offset_from_level_rad;
    volatile float neutral_position_rad;
    volatile float requested_position_rad;
    volatile float command_position_rad;
    volatile float feedback_position_rad;
    volatile float feedback_velocity_rad_s;
    volatile float feedback_torque_nm;
    volatile uint32_t feedback_age_ms;
    volatile uint32_t motor_error;
    volatile uint32_t motor_mos_temperature_c;
    volatile uint32_t motor_rotor_temperature_c;

    volatile uint32_t can_rx_count;
    volatile uint32_t can_tx_count;
    volatile uint32_t can_tx_error_count;
    volatile uint32_t usb_rx_bytes;
    volatile uint32_t usb_rx_overflow;
    volatile uint32_t usb_tx_drop;

    volatile int32_t vision_position_um;
    volatile int32_t vision_velocity_um_s;
    volatile uint32_t vision_age_ms;
    volatile uint32_t vision_flags;
    volatile uint32_t vision_closed_loop_enabled;
} GimbalDebug;

extern volatile GimbalDebug g_gimbal_debug;

void gimbal_app_init(uint32_t now_ms);
void gimbal_app_poll(uint32_t now_ms);
void gimbal_app_on_vision_sample(const VisionSample *sample);

#endif
