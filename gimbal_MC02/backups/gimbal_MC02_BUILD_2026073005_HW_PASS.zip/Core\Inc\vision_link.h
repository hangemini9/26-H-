#ifndef VISION_LINK_H
#define VISION_LINK_H

#include <stdint.h>

/*
 * Application-level sample passed to the controller after the Jetson wire
 * protocol is decoded.  The USB wire format is deliberately not frozen yet.
 * Position is relative to the detected pipe center; down/right along the pipe
 * is positive according to the team's current convention.
 */
typedef struct
{
    uint32_t run_id;
    uint32_t sequence;
    uint32_t capture_time_ms;
    uint32_t receive_time_ms;
    int32_t position_um;
    int32_t velocity_um_s;
    uint16_t confidence_permille;
    uint16_t flags;
} VisionSample;

#define VISION_FLAG_BALL_VALID       (1U << 0)
#define VISION_FLAG_PIPE_VALID       (1U << 1)
#define VISION_FLAG_CALIBRATED       (1U << 2)

#endif
